/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author QXC
 */
public class NumeroDeBolita {
     private int numero;

    public NumeroDeBolita(int numero) {
        this.numero = numero;
    }

    public NumeroDeBolita() {
    }

    public int getNumero() {
        return numero; 
    }
    public void setNumero(int numero) {
        this.numero = numero; 
    }
}

